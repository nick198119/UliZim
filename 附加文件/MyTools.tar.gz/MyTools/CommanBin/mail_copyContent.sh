#!/bin/bash
xsel -b | mail -s "便笺" nick198119@gmail.com
#xsel -b | mail -s "便笺" fzy.uli@qq.com
#xsel -b | mail -s "便笺" nick198119@qq.com

notify-send "发送完成" "`xsel -b`"

sleep 30
notify-send "检查是否成功……" "`sendmail -bp`"

exit 0
