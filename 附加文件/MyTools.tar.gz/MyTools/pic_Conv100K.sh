#!/bin/bash

for arg in "$@"
do
dir="$arg"
dirname=$(basename "$dir")
dest=$HOME/图片/转换输出/"$dirname"

if [[ ! -d "$dir" ]]
then
    notify-send  "$0" 'Error argument,no this dir'
    exit 0
fi

mkdir -p "$dest"
for file in "$dir"/*.jpg "$dir"/*.jpeg
do 
    fileName=$(basename "$file")
    convert -resize '400x400'  "$file" "$dest"/"$fileName" 
done

notify-send "$0:$dirname" "处理完成，存放于$dest"
done
