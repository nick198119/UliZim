#!/bin/bash

unit=`kdialog --title "切割文件(1)" --combobox 切割单位 M K`
if [[ "$unit" == "" ]]
then
  exit 0
fi
cnt=`kdialog --title "切割文件(2)" --inputbox 切割大小：`
if [[ "$cnt" == "" ]]
then
  exit 0
fi

for arg in "$@"
do
    par_dir=`dirname "$arg" `
    fileSuffix="."${arg##*.}
    dirName=`basename "$arg" "$fileSuffix"`
    fileName=`basename "$arg"`

    destDir="$par_dir""/""$dirName"

    if [[ -d "$destDir" ]]
    then
	destDir="$destDir""_dir"
    fi

    mkdir "$destDir"

    cd "$destDir"
    splitSpice="$cnt""$unit"
    split -C $splitSpice -d ../"$fileName"

    i=0
    for file in `ls -v`
    do
	(( i++ ))
	mv "$file" "$dirName"_"$i""$fileSuffix"
    done
    cd -
done
