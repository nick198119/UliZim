#!/bin/bash


for arg in "$@"
do
    currentDir=$(dirname "$arg")
    cd "$currentDir"
    mkdir -p build
    base=$(basename "$arg" .h)
    moc "$arg" -o build/"$base"".moc"
done

notify-send --icon emacs "$0" "$*"
    
