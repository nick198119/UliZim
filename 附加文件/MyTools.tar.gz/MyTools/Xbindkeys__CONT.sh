#!/bin/bash
kill -9 $(ps caxu | grep xbindkeys | awk '{print $2}')
xbindkeys
