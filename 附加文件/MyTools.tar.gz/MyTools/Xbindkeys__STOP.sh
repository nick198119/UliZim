#!/bin/bash
ps caxu | grep xbindkeys
if [  $? = 0 ]
then
  kill -9 $(ps caxu | grep xbindkeys | awk '{print $2}')
fi

