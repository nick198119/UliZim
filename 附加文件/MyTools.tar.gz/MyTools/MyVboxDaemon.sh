#!/bin/bash

machine="Simple_xp"
con="eth0"
VboxCpuLim=8
machConfFile="$HOME/.machConf"
nmDhcpConfFile="$HOME/.nmDhcpConf"

function SendMsg()
{
    if [[ ! $2 ]]
    then
	echo "$machine :     $1"
	notify-send "$0: " "$machine:    $1" 2>/dev/null
    else
	echo "$1"
	notify-send "$0: " "$1"  2>/dev/null
    fi
} 


if [[ -f "$machConfFile" && -f "$nmDhcpConfFile" ]]
then
    read machine <"$machConfFile"
    read con <"$nmDhcpConfFile"
else
    SendMsg "No $machConfFile or $nmDhcpConfFile ,use default config in script" 
fi


while getopts "splm:" option
do
    case $option in
	s) 
	    start=1
	    ;;
	p)
	    VBoxManage controlvm "$machine" savestate
	    SendMsg "Poweroff ..." 
	    ;;
	l)
	    PS3="Select Dhcp conection:   "
	    select var in `nmcli con 2>/dev/null | grep '.*-.*-.*' | awk 'BEGIN{FS="   "};{ print $1 }'`
	    do
		con="$var"
		echo "$var will be set default conection for this script"
		echo "$var" >"$nmDhcpConfFile"
		break
	    done

	    PS3="Select One Machine :    "
	    select var in $(VBoxManage list vms | grep '".*".*{.*}' |  cut -d '"'  -f2) "exit"
	    do
		case "$var" in 
		    "exit")
			exit 0;;
		     *)
			machine="$var"
			echo -n "start this machine now?([y]/n) :   " 
			read ans
			if [[ "$ans" == 'y' || "t$ans" == "t"  ]]
			then
			    echo -n "Set if the default machine?([y]/n) :   "
			    read ans
			    if [[ $ans == 'y' || "t$ans" == "t"  ]]
			    then
				echo "$var" >"$machConfFile"
			    fi
			    $0 -s -m "$machine" &
			fi


			exit 0
			;;
		esac
		break
	    done
	    ;;
	m)
	    machine="$OPTARG"
	    ;;
    esac
done

if [[ "$start" == 1 || $# == 0 ]]
then
    if VBoxManage list runningvms | grep '".*".*{.*}'
    then
	SendMsg "One machine is running now...",1 
	exit 0
    fi

    if [[ `tty` == /dev/pts/* ]]
    then
	trap 'VBoxManage controlvm  $machine savestate &;echo "Poweroff:  `date`" >$HOME/.VboxDaemonLog ;exit 0' SIGTERM SIGINT SIGTSTP SIGHUP

    else
	trap 'VBoxManage controlvm  $machine savestate &;echo "Poweroff:  `date`" >$HOME/.VboxDaemonLog ;exit 0' SIGTERM SIGINT SIGTSTP SIGHUP
    fi

    (
    sleep 15
    nmcli con up id "$con"
    )&

    SendMsg "Start now..."
    VBoxHeadless -startvm "$machine"&

#    VBoxPid=$!
#    sleep 55
#
#    VboxHeadPid=$(ps caux | grep VBoxHeadless | awk '{print $2}')
#    cpulimit -p `ps caux | grep 'VBoxHeadless' | awk '{print $2}'` -l $VboxCpuLim -z &
#
#    cpuLiID=$!
#    trap 'kill  $! ;conti=1' SIGUSR1
#    trap 'cpulimit -p $VboxHeadPid -l 6 -z &'  SIGUSR2


    while true
    do
	wait 
	sleep 24h &
	wait
    done

fi
exit 0


