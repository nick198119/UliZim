 #!/bin/sh
CHROME_BIN="/usr/bin/chromium"
FIREFOX_BIN="/usr/bin/firefox"
KONQUEROR_BIN="/usr/bin/rekonq"
OPERA_BIN="/usr/bin/opera"


FAVORITE=$KONQUEROR_BIN

# if [ "`pidof $OPERA_BIN`" != "" ]; then
#         FAVORITE=$OPERA_BIN
# fi

if [ "`pidof $KONQUEROR_BIN`" != "" ]; then
        FAVORITE=$KONQUEROR_BIN
fi


ps cuax | grep  -q firefox  &&      FAVORITE=$FIREFOX_BIN




$FAVORITE "$1"
