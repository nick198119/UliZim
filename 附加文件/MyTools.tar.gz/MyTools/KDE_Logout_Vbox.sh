#!/bin/bash
VBoxManage controlvm "Simple_xp"  savestate &
sleep 1
qdbus org.kde.ksmserver /KSMServer logout 1 3 2
