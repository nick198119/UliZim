#!/bin/bash 

notify-send "下载" "$1"
wget -P $HOME/下载/mp3/ "$1"

notify-send "下载完成" "$1"
