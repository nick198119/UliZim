#!/bin/bash
cd "$1"
proFile="$(find . -iname "CMakeLists.txt")"
if [[ "$proFile""t" == "t" ]]
then
  direc="$1""/""src/build/"
else
  direc="$1""/""build/"
fi

for uiFile in `find . -iname "*.ui"`
do
  mkdir -p "$direc"
  uic "$uiFile" -o "$direc""/ui_"$(basename "$uiFile" .ui)".h"
done