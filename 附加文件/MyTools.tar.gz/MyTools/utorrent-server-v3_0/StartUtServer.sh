#!/bin/bash
pkill utserver
cd /home/uli/bin/MyTools/utorrent-server-v3_0
./utserver &
