#!/bin/bash
Command=$(xsel -b -o)
Command=${Command/sudo/}
Uri=$($Command --print-uris -y --force-yes | cut -d "'" -f2 | grep -i deb)
notify-send "Fetched Uris:" "$Uri"
echo "$Uri" | tee ~/uriList.lst
echo "$Uri" | xsel -b -i
exit 0
