#!/bin/sh
exec qdbus org.kde.kwin /KWin org.kde.KWin.previousDesktop