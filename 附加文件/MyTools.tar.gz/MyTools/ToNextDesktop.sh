#!/bin/sh
exec qdbus org.kde.kwin /KWin org.kde.KWin.nextDesktop
#exec xte 'keydown Alt_L' 'key Space' 'keyup Alt_L'
