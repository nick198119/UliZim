#!/bin/sh
exec /usr/bin/xte 'keydown Control_L' 'key F7' 'keyup Control_L'
